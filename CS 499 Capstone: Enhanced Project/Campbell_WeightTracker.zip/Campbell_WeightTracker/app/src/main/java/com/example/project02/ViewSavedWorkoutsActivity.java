package com.example.project02;

import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class ViewSavedWorkoutsActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private String username;
    private LinearLayout savedWorkoutsLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_saved_workouts);

        username = getIntent().getStringExtra("username");
        db = new DatabaseHelper(this);

        savedWorkoutsLayout = findViewById(R.id.savedWorkoutsLayout);

        loadSavedWorkouts();
    }

    private void loadSavedWorkouts() {
        List<Workout> workouts = db.getWorkoutsForUser(username);

        if (workouts.isEmpty()) {
            TextView emptyMsg = new TextView(this);
            emptyMsg.setText("No saved workouts yet.");
            savedWorkoutsLayout.addView(emptyMsg);
            return;
        }

        for (Workout w : workouts) {
            // Category header
            TextView categoryView = new TextView(this);
            categoryView.setText("Category: " + w.getCategory());
            categoryView.setTextSize(20);
            categoryView.setPadding(0, 20, 0, 10);
            savedWorkoutsLayout.addView(categoryView);

            // Exercises list
            TextView exercisesView = new TextView(this);
            exercisesView.setText("Exercises:\n" + w.getExercises().replace(",", "\n"));
            exercisesView.setPadding(0, 0, 0, 20);
            savedWorkoutsLayout.addView(exercisesView);
        }
    }
}
