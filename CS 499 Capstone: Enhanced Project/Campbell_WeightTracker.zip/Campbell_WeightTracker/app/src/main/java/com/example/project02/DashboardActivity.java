package com.example.project02;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import android.app.AlertDialog;
import android.widget.Toast;
import android.widget.ProgressBar;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private TextView recentWeightText, goalWeightText, dailyIntakeText;
    private Button setGoalButton, openLogsButton, setCalorieGoalButton, workoutPlannerButton;
    private ProgressBar progressBar;
    private TextView progressLabel;

    private DatabaseHelper db;
    private String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        db = new DatabaseHelper(this);

        username = getIntent().getStringExtra("username");

        // assign view variables
        recentWeightText = findViewById(R.id.recentWeightText);
        goalWeightText = findViewById(R.id.goalWeightText);
        setGoalButton = findViewById(R.id.setGoalButton);
        dailyIntakeText = findViewById(R.id.dailyIntakeText);
        openLogsButton = findViewById(R.id.openLogsButton);
        progressBar = findViewById(R.id.progressBar);
        progressLabel = findViewById(R.id.progressLabel);
        setCalorieGoalButton = findViewById(R.id.setCalorieGoalButton);
        workoutPlannerButton = findViewById(R.id.workoutPlannerButton);

        loadDashboard();

        // prompts user to set goal weight
        setGoalButton.setOnClickListener(v -> promptForGoal());

        // navigates user to weight log screen
        openLogsButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, DatabaseActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        setCalorieGoalButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, CalorieGoalCalculatorActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        workoutPlannerButton.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, WorkoutPlannerActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        // creates channel to create notification that user has reached goal weight
        createNotificationChannel();
    }

    private void loadDashboard() {
        String initial = db.getInitialWeight();
        String recent = db.getMostRecentWeight();
        String goal = db.getGoalWeight(username);

        // Load daily calorie intake goal
        String dailyIntake = db.getCalorieGoal(username);

        if (dailyIntake == null) {
            dailyIntakeText.setText("Daily Intake Goal: Not Set");
        } else {
            dailyIntakeText.setText("Daily Intake Goal: " + dailyIntake + " cal/day");
        }

        // display recent weight
        if (recent == null) {
            recentWeightText.setText("Most Recent Weight: None");
        } else {
            recentWeightText.setText("Most Recent Weight: " + recent);
        }

        // display goal weight
        if (goal == null) {
            goalWeightText.setText("Goal Weight: Not Set");
            progressBar.setProgress(0);
            progressLabel.setText("Progress: No goal set");
            return; // stop here — no goal means no progress calculation
        } else {
            goalWeightText.setText("Goal Weight: " + goal);
        }

        // check if goal reached
        if (recent != null) {
            checkGoalReached(recent, goal);
        }

        // updates progress bar
        updateProgressBar(initial, recent, goal);
    }

    private void promptForGoal() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Goal Weight");

        final EditText input = new EditText(this);
        input.setHint("Enter goal weight");
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String goal = input.getText().toString().trim();

            if (goal.isEmpty()) {
                Toast.makeText(this, "Goal cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            db.setGoalWeight(username, goal);
            goalWeightText.setText("Goal Weight: " + goal);
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }

    private void createNotificationChannel() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            CharSequence name = "GoalChannel";
            String description = "Notifications for reaching goal weight";
            int importance = android.app.NotificationManager.IMPORTANCE_HIGH;

            android.app.NotificationChannel channel =
                    new android.app.NotificationChannel("goalChannel", name, importance);
            channel.setDescription(description);

            android.app.NotificationManager notificationManager =
                    getSystemService(android.app.NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void sendGoalReachedNotification() {
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this, "goalChannel")
                        .setSmallIcon(R.drawable.ic_launcher_foreground)
                        .setContentTitle("Goal Reached!")
                        .setContentText("Congratulations! You reached your goal weight.")
                        .setPriority(NotificationCompat.PRIORITY_HIGH);

        NotificationManagerCompat manager = NotificationManagerCompat.from(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            manager.notify(1, builder.build());
        }
    }

    private void checkGoalReached( String recent, String goal) {
        try {
            float recentVal = Float.parseFloat(recent);
            float goalVal = Float.parseFloat(goal);

            boolean reached = false;

            if (recentVal == goalVal) {
                reached = true;
            } else if (recentVal < goalVal) {
                // Weight gain goal
                reached = recentVal >= goalVal;
            } else if (recentVal > goalVal) {
                // Weight loss goal
                reached = recentVal <= goalVal;
            }

            if (reached) {
                sendGoalReachedNotification();
            }

        } catch (Exception e) {
            // ignore parsing errors
        }
    }

    private void updateProgressBar(String initial, String recent, String goal) {

        if (initial == null || recent == null || goal == null) {
            progressBar.setProgress(0);
            progressLabel.setText("Progress: Not enough data");
            return;
        }

        float initialVal = Float.parseFloat(initial);
        float recentVal = Float.parseFloat(recent);
        float goalVal = Float.parseFloat(goal);

        float progressPercent;

        // Weight loss goal
        if (initialVal > goalVal) {
            progressPercent = ((initialVal - recentVal) / (initialVal - goalVal)) * 100;
        }
        // Weight gain goal
        else {
            progressPercent = ((recentVal - initialVal) / (goalVal - initialVal)) * 100;
        }

        // Clamp 0–100
        progressPercent = Math.max(0, Math.min(progressPercent, 100));

        progressBar.setProgress((int) progressPercent);
        progressLabel.setText("Progress: " + (int) progressPercent + "%");
    }
}