package com.example.project02;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // database Info
    private static final String DB_NAME = "WeightLog.db";
    private static final int DB_VERSION = 4;

    // weight log table info
    private static final String TABLE_WEIGHTLOGS = "weightlogs";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT ="weight";

    // users table info
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // user goals table
    private static final String TABLE_GOAL = "goal";
    private static final String COLUMN_GOAL_ID = "goal_id";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";
    private static final String COLUMN_GOAL_INTAKE = "goal_intake";
    private static final String COLUMN_GOAL_USER = "goal_user";

    // user created workouts table
    private static final String TABLE_WORKOUTS = "workouts";
    private static final String COLUMN_WORKOUTS_ID = "workouts_id";
    private static final String COLUMN_WORKOUTS_USER = "workouts_user";
    private static final String COLUMN_WORKOUT_CATEGORY = "workouts_category";
    private static final String COLUMN_WORKOUTS_EXERCISES = "workouts_exercises";

    // workout plan table
    private static final String TABLE_WORKOUT_PLAN = "workout_plan";
    private static final String COLUMN_WORKOUT_PLAN_ID ="workout_plan_id";
    private static final String COLUMN_WORKOUT_PLAN_USER = "workout_plan_user";
    private static final String COLUMN_WORKOUT_PLAN_DAY = "workout_plan_day";
    private static final String COLUMN_WORKOUT_PLAN_WORKOUT_ID ="workout_plan_workout_id";

    // constructor
    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        // create users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT UNIQUE, "
                + COLUMN_PASSWORD + " TEXT)";

        // create weight log table
        String CREATE_WEIGHTLOGS_TABLE = "CREATE TABLE " + TABLE_WEIGHTLOGS + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_DATE + " TEXT NOT NULL,"
                + COLUMN_WEIGHT + " TEXT NOT NULL)";

        // create goal weight table
        String CREATE_GOAL_TABLE = "CREATE TABLE " + TABLE_GOAL + " ("
                + COLUMN_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_GOAL_USER + " TEXT, "
                + COLUMN_GOAL_WEIGHT + " TEXT, "
                + COLUMN_GOAL_INTAKE + " TEXT)";

        String CREATE_WORKOUTS_TABLE = "CREATE TABLE " + TABLE_WORKOUTS + " ("
                + COLUMN_WORKOUTS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_WORKOUTS_USER + " TEXT, "
                + COLUMN_WORKOUT_CATEGORY + " TEXT, "
                + COLUMN_WORKOUTS_EXERCISES + " TEXT)";

        String CREATE_WORKOUT_PLAN_TABLE = "CREATE TABLE " + TABLE_WORKOUT_PLAN + " ("
                + COLUMN_WORKOUT_PLAN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_WORKOUT_PLAN_USER + " TEXT,"
                + COLUMN_WORKOUT_PLAN_DAY + " INT,"
                + COLUMN_WORKOUT_PLAN_WORKOUT_ID + " INT)";

        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_WEIGHTLOGS_TABLE);
        db.execSQL(CREATE_GOAL_TABLE);
        db.execSQL(CREATE_WORKOUTS_TABLE);
        db.execSQL(CREATE_WORKOUT_PLAN_TABLE);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop old table if exists
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTLOGS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WORKOUTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WORKOUT_PLAN);
        onCreate(db);
    }

    /*** USER TABLE METHODS ***/

    // create new user
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // check if credentials are valid
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " +
                        COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /*** WEIGHT LOG TABLE METHODS ***/

    // insert data
    public boolean insertLog(String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        long result = db.insert(TABLE_WEIGHTLOGS, null, values);

        return result != -1; // returns true if insert succeeds
    }

    // get all weight logs
    public Cursor getAllLogs() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHTLOGS + " ORDER BY " + COLUMN_ID + " DESC", null);
    }

    // get most recent weight log
    public String getMostRecentWeight() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT weight FROM weightlogs ORDER BY id DESC LIMIT 1",
                null
        );

        if (cursor.moveToFirst()) {
            String weight = cursor.getString(0);
            cursor.close();
            return weight;
        }

        cursor.close();
        return null;
    }

    // get initial weight log
    public String getInitialWeight() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT weight FROM weightlogs ORDER BY id ASC LIMIT 1",
                null
        );

        if (cursor.moveToFirst()) {
            String weight = cursor.getString(0);
            cursor.close();
            return weight;
        }

        cursor.close();
        return null; // no logs yet
    }

    // delete log by id
    public boolean deleteLog(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_WEIGHTLOGS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    // update weight log by id
    public boolean updateLog(int id, String newDate, String newWeight) {
        SQLiteDatabase db =this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_DATE, newDate);
        values.put(COLUMN_WEIGHT, newWeight);

        int rows = db.update(TABLE_WEIGHTLOGS,  values, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    /*** GOAL WEIGHT METHODS ***/

    // set goal weight
    public boolean setGoalWeight(String username, String goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_USER, username);
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        long result = db.insert(TABLE_GOAL, null, values);
        return result != -1;
    }

    // get goal weight
    public String getGoalWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_GOAL_WEIGHT + " FROM " + TABLE_GOAL +
                        " WHERE " + COLUMN_GOAL_USER + "=? LIMIT 1",
                new String[]{username}
        );

        if (cursor.moveToFirst()) {
            String goal = cursor.getString(0);
            cursor.close();
            return goal;
        }

        cursor.close();
        return null; // no goal set
    }

    public boolean saveCalorieGoal(String username, int calories) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_GOAL_USER, username);
        values.put(COLUMN_GOAL_INTAKE, String.valueOf(calories));

        long result = db.insert(TABLE_GOAL, null, values);
        return result != -1;
    }

    public String getCalorieGoal(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_GOAL_INTAKE + " FROM " + TABLE_GOAL +
                        " WHERE " + COLUMN_GOAL_USER + "=? ORDER BY " + COLUMN_GOAL_ID + " DESC LIMIT 1",
                new String[]{username}
        );

        if (cursor.moveToFirst()) {
            String intake = cursor.getString(0);
            cursor.close();
            return intake;
        }

        cursor.close();
        return null;
    }

    // inserts user created workout into table
    public boolean insertWorkout(String username, String category, String exercises) {
        SQLiteDatabase db = this.getWritableDatabase();

        // delete old workout for this category
        deleteWorkoutByCategory(username, category);

        ContentValues values = new ContentValues();
        values.put(COLUMN_WORKOUTS_USER, username);
        values.put(COLUMN_WORKOUT_CATEGORY, category);
        values.put(COLUMN_WORKOUTS_EXERCISES, exercises);

        long result = db.insert(TABLE_WORKOUTS, null, values);
        return result != -1;
    }

    // deletes workout for category
    public void deleteWorkoutByCategory(String username, String category) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WORKOUTS,
                COLUMN_WORKOUTS_USER + "=? AND " + COLUMN_WORKOUT_CATEGORY + "=?",
                new String[]{username, category});
    }

    // query that fetches user created workouts
    public List<Workout> getWorkoutsForUser(String username) {
        List<Workout> workouts = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_WORKOUTS_ID + ", " + COLUMN_WORKOUT_CATEGORY + ", "
                        + COLUMN_WORKOUTS_EXERCISES + " FROM "
                        + TABLE_WORKOUTS + " WHERE " + COLUMN_WORKOUTS_USER + " =?",
                new String[]{username}
        );

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String category = cursor.getString(1);
                String exercises = cursor.getString(2);

                workouts.add(new Workout(id, category, exercises));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return workouts;
    }

    // assigns workouts to days to be used in workout planner
    public boolean assignWorkoutToDay(String username, int dayNumber, int workoutId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_WORKOUT_PLAN_USER, username);
        values.put(COLUMN_WORKOUT_PLAN_DAY, dayNumber);
        values.put(COLUMN_WORKOUT_PLAN_WORKOUT_ID, workoutId);

        long result = db.insert("workout_plan", null, values);
        return result != -1;
    }

    // retrieves workout assigned to specified day
    public Integer getAssignedWorkoutId(String username, int dayNumber) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_WORKOUT_PLAN_WORKOUT_ID +" FROM " + TABLE_WORKOUT_PLAN
                        + " WHERE " + COLUMN_WORKOUT_PLAN_USER +" =? AND "
                        + COLUMN_WORKOUT_PLAN_DAY + " =? LIMIT 1",
                new String[]{username, String.valueOf(dayNumber)}
        );

        if (cursor.moveToFirst()) {
            int id = cursor.getInt(0);
            cursor.close();
            return id;
        }

        cursor.close();
        return null;
    }

    // retrieves workout category by workout id
    public String getWorkoutCategoryById(int workoutId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_WORKOUT_CATEGORY +
                        " FROM " + TABLE_WORKOUTS +
                        " WHERE " + COLUMN_WORKOUTS_ID + " = ? LIMIT 1",
                new String[]{String.valueOf(workoutId)}
        );

        if (cursor.moveToFirst()) {
            String category = cursor.getString(0);
            cursor.close();
            return category;
        }

        cursor.close();
        return null;
    }
}
