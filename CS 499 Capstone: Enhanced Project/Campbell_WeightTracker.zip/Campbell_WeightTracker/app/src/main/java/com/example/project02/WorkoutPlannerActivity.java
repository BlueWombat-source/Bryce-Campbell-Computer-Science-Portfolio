package com.example.project02;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WorkoutPlannerActivity extends AppCompatActivity {

    private String username;
    private DatabaseHelper db;
    private GridLayout gridLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_planner);

        // initialize database
        db = new DatabaseHelper(this);

        username = getIntent().getStringExtra("username");

        gridLayout = findViewById(R.id.gridLayout);

        Button createWorkoutButton = findViewById(R.id.createWorkout_button);
        createWorkoutButton.setOnClickListener(v -> {
            Intent intent = new Intent(WorkoutPlannerActivity.this, CreateWorkoutActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        Button viewSavedWorkouts = findViewById(R.id.viewSavedWorkouts_button);
        viewSavedWorkouts.setOnClickListener(v -> {
            Intent intent = new Intent(WorkoutPlannerActivity.this, ViewSavedWorkoutsActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
        });

        // fill out planner
        for (int i = 0; i < 7; ++i) {

            int dayNumber = i + 1;

            // --- DAY BUTTON (Column 0) ---
            Button dayButton = new Button(this);
            dayButton.setText("Day " + dayNumber);
            dayButton.setTextColor(getResources().getColor(R.color.white));
            dayButton.setBackgroundColor(getResources().getColor(R.color.blue));

            GridLayout.LayoutParams paramsDay = new GridLayout.LayoutParams();
            paramsDay.rowSpec = GridLayout.spec(dayNumber, 1);
            paramsDay.columnSpec = GridLayout.spec(0, 1f);
            paramsDay.setMargins(10, 10, 10, 10);
            dayButton.setLayoutParams(paramsDay);

            gridLayout.addView(dayButton);


            // --- CATEGORY INDICATOR (Column 1) ---
            TextView categoryIndicator = new TextView(this);
            categoryIndicator.setTextSize(16);
            categoryIndicator.setTypeface(null, Typeface.BOLD);
            categoryIndicator.setBackground(getResources().getDrawable(R.drawable.nameplate));
            categoryIndicator.setGravity(Gravity.CENTER_VERTICAL);

            // Get assigned workout ID
            Integer assignedWorkoutId = db.getAssignedWorkoutId(username, dayNumber);

            if (assignedWorkoutId != null) {
                String category = db.getWorkoutCategoryById(assignedWorkoutId);
                categoryIndicator.setText(category);

                // Color code the nameplate background
                int color = getCategoryColor(category);
                categoryIndicator.setBackgroundTintList(ColorStateList.valueOf(color));
            } else {
                categoryIndicator.setText("");
            }

            GridLayout.LayoutParams paramsIndicator = new GridLayout.LayoutParams();
            paramsIndicator.rowSpec = GridLayout.spec(dayNumber, 1);
            paramsIndicator.columnSpec = GridLayout.spec(1, 3f);
            paramsIndicator.setMargins(10, 10, 10, 10);
            categoryIndicator.setLayoutParams(paramsIndicator);

            gridLayout.addView(categoryIndicator);


            // --- EDIT BUTTON (Column 2) ---
            ImageButton editButton = new ImageButton(this);
            editButton.setImageDrawable(getResources().getDrawable(R.drawable.icon_edit));
            editButton.setBackgroundColor(getResources().getColor(R.color.blue));

            GridLayout.LayoutParams paramsEdit = new GridLayout.LayoutParams();
            paramsEdit.rowSpec = GridLayout.spec(dayNumber, 1);
            paramsEdit.columnSpec = GridLayout.spec(2, 1f);
            paramsEdit.setMargins(10, 10, 10, 10);
            editButton.setLayoutParams(paramsEdit);

            editButton.setOnClickListener(v -> {
                Intent intent = new Intent(WorkoutPlannerActivity.this, SelectWorkoutForDayActivity.class);
                intent.putExtra("username", username);
                intent.putExtra("dayNumber", dayNumber);
                startActivity(intent);
            });

            gridLayout.addView(editButton);
        }
    }

    private int getCategoryColor(String category) {
        switch (category) {
            case "Chest": return getResources().getColor(R.color.red);
            case "Back": return getResources().getColor(R.color.green);
            case "Legs": return getResources().getColor(R.color.orange);
            case "Shoulders": return getResources().getColor(R.color.purple);
            case "Biceps": return getResources().getColor(R.color.blue_light);
            case "Triceps": return getResources().getColor(R.color.yellow);
            case "Abs": return getResources().getColor(R.color.cyan);
            case "Cardio": return getResources().getColor(R.color.pink);
            default: return getResources().getColor(R.color.gray);
        }
    }
}
