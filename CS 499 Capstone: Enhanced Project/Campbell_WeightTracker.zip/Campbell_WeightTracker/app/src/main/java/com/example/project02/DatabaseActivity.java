package com.example.project02;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.database.Cursor;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

public class DatabaseActivity extends AppCompatActivity {

    private EditText inputDate, inputWeight;
    private Button buttonAdd;
    private LinearLayout dataContainer;

    private String username;

    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        // initialize database
        db = new DatabaseHelper(this);

        username = getIntent().getStringExtra("username");

        // link UI elements
        inputDate = findViewById(R.id.inputDate);
        inputWeight = findViewById(R.id.inputWeight);
        buttonAdd = findViewById(R.id.buttonAdd);
        dataContainer = findViewById(R.id.dataContainer);

        // load existing logs
        loadLogs();

        // add button listener
        buttonAdd.setOnClickListener(v -> addLog());

        Button buttonReturnDashboard = findViewById(R.id.buttonReturnDashboard);

        buttonReturnDashboard.setOnClickListener(v -> {
            Intent intent = new Intent(DatabaseActivity.this, DashboardActivity.class);

            // Pass username back to dashboard
            intent.putExtra("username", getIntent().getStringExtra("username"));

            startActivity(intent);
            finish();
        });
    }

    // add new log
    private void addLog() {
        String date = inputDate.getText().toString().trim();
        String weight = inputWeight.getText().toString().trim();

        if (date.isEmpty() || weight.isEmpty()) {
            Toast.makeText(this, "Please enter both date and weight", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean inserted = db.insertLog(date, weight);

        if (inserted) {
            Toast.makeText(this, "Log added", Toast.LENGTH_SHORT).show();
            inputDate.setText("");
            inputWeight.setText("");
            loadLogs(); // refresh grid
        } else {
            Toast.makeText(this, "Error adding log", Toast.LENGTH_SHORT).show();
        }
    }


    // load all logs into grid
    private void loadLogs() {
        dataContainer.removeAllViews(); // clear old rows

        Cursor cursor = db.getAllLogs();

        if (cursor.getCount() == 0) {
            return;
        }

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
            String weight = cursor.getString(cursor.getColumnIndexOrThrow("weight"));

            addRowToLayout(id, date, weight);
        }

        cursor.close();
    }

    // create a row
    private void addRowToLayout(int id, String date, String weight) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 12, 0, 12);

        // date text
        TextView dateText = new TextView(this);
        dateText.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        dateText.setText(date);

        // weight text
        TextView weightText = new TextView(this);
        weightText.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        weightText.setText(weight);

        // delete button
        Button deleteButton = new Button(this);
        deleteButton.setText("X");
        deleteButton.setOnClickListener(v -> {
            db.deleteLog(id);
            loadLogs();
        });

        // add views to row
        row.addView(dateText);
        row.addView(weightText);
        row.addView(deleteButton);

        // add row to container
        dataContainer.addView(row);
    }
}