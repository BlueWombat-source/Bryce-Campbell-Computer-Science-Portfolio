package com.example.project02;

public class Workout {
    private int id;
    private String category;
    private String exercises;

    public Workout(int id, String category, String exercises) {
        this.id = id;
        this.category = category;
        this.exercises = exercises;
    }

    public int getId() { return id; }
    public String getCategory() { return category; }
    public String getExercises() { return exercises; }
}

