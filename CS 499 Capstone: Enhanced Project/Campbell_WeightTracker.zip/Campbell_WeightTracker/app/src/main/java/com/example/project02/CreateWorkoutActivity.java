package com.example.project02;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.Spinner;
import androidx.activity.EdgeToEdge;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;


public class CreateWorkoutActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private String username, workoutCategory;
    private DatabaseHelper db;
    private LinearLayout workoutSelections;
    private CheckBox[] exercises;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_workout);

        username = getIntent().getStringExtra("username");

        // initialize database
        db = new DatabaseHelper(this);

        // assigns variable to hold checkboxes for exercises
        workoutSelections = findViewById(R.id.workoutSelections);

        // assigns spinner variable
        Spinner workoutCategorySpinner = findViewById(R.id.spinner_workoutCategory);
        workoutCategorySpinner.setOnItemSelectedListener(this);
        // populates spinner with options from string-array resource
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.workoutCategories_array,
                android.R.layout.simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        workoutCategorySpinner.setAdapter(adapter);

        Button saveWorkout = findViewById(R.id.saveWorkout_button);
        saveWorkout.setOnClickListener(v -> saveWorkout());
    }


    // handles spinner selection events
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        workoutCategory = parent.getItemAtPosition(position).toString();

        // clear out previously selected category workouts
        workoutSelections.removeAllViews();
        // populate options for exercises for selected category
        populateExerciseOptions(workoutCategory);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {workoutCategory = "";}

    // populates options for exercises based on the selected category
    public void populateExerciseOptions(String workoutCategory) {

        // changes value of workoutArray depending on category selected
        String[] workoutArray;
        switch (workoutCategory) {
            case "Chest":
                workoutArray = getResources().getStringArray(R.array.chestExercises_array);
                break;

            case "Triceps":
                workoutArray = getResources().getStringArray(R.array.tricepExercises_array);
                break;

            case "Biceps":
                workoutArray = getResources().getStringArray(R.array.bicepExercises_array);
                break;

            case "Shoulders":
                workoutArray = getResources().getStringArray(R.array.shoulderExercises_array);
                break;

            case "Legs":
                workoutArray = getResources().getStringArray(R.array.legExercises_array);
                break;

            case "Back":
                workoutArray = getResources().getStringArray(R.array.backExercises_array);
                break;

            case "Abs":
                workoutArray = getResources().getStringArray(R.array.abExercises_array);
                break;

            case "Cardio":
                workoutArray = getResources().getStringArray(R.array.cardioExercises_array);
                break;

            default:
                Toast.makeText(this, "Select a workout category", Toast.LENGTH_SHORT).show();
                return;
        }

        int size = workoutArray.length;
        /*
           reset exercises array to house exercise options
           from most recently selected category
        */
        exercises = new CheckBox[size];
        for (int i = 0; i < size; ++i) {
            CheckBox exerciseCheckBox = new CheckBox(this);
            exerciseCheckBox.setText(workoutArray[i]);
            exercises[i] = exerciseCheckBox;
            workoutSelections.addView(exerciseCheckBox);
        }
    }

    public void saveWorkout() {
        // user must select workout catagory before saving workout
        if (workoutCategory == null || workoutCategory.isEmpty()) {
            Toast.makeText(this, "Select a workout category first", Toast.LENGTH_SHORT).show();
            return;
        }

        List<String> selectedExercises = new ArrayList<>();

        for (CheckBox cb : exercises) {
            if (cb.isChecked()) {
                selectedExercises.add(cb.getText().toString());
            }
        }

        if (selectedExercises.isEmpty()) {
            Toast.makeText(this, "Select at least one exercise", Toast.LENGTH_SHORT).show();
            return;
        }

        // convert list to a single string (comma separated)
        String exerciseList = TextUtils.join(",", selectedExercises);

        // save to database
        boolean inserted = db.insertWorkout(username, workoutCategory, exerciseList);

        if (inserted) {
            Toast.makeText(this, "Workout saved!", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(this, "Error saving workout", Toast.LENGTH_SHORT).show();
        }
    }
}
