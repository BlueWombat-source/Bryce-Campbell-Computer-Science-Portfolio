package com.example.project02;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.Spinner;
import androidx.activity.EdgeToEdge;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

public class CalorieGoalCalculatorActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private EditText ageInput, heightFeetInput, heightInchesInput, weightInput;
    private Spinner activityLevelInput;
    private String activityLevel;

    private String username;

    private DatabaseHelper db = new DatabaseHelper(this);


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_calorie_goal_calculator);

        username = getIntent().getStringExtra("username");

        // assigns variables to be used in calculating basal metabolic rate
        ageInput = findViewById(R.id.ageInput);
        heightFeetInput = findViewById(R.id.heightFeetInput);
        heightInchesInput = findViewById(R.id.heightInchesInput);
        weightInput = findViewById(R.id.weightInput);

        // populates spinner with options from string resource file
        activityLevelInput = findViewById(R.id.spinner_activity);
        activityLevelInput.setOnItemSelectedListener(this);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.activityLevel_array,
                android.R.layout.simple_spinner_dropdown_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        activityLevelInput.setAdapter(adapter);

        Button calculate = findViewById(R.id.calculateButton);

        // calculates the user's basal metabolic rate using the acquired input
        // uses the Mifflin-St Jeor Equation
        calculate.setOnClickListener(v -> {
            // input validation, ensures all required fields are filled
            if (ageInput.getText().toString().trim().isEmpty() ||
                    heightFeetInput.getText().toString().trim().isEmpty() ||
                    heightInchesInput.getText().toString().trim().isEmpty() ||
                    weightInput.getText().toString().trim().isEmpty()) {

                Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // convert input text to integers
            int age = Integer.parseInt(ageInput.getText().toString());
            int heightFeet = Integer.parseInt(heightFeetInput.getText().toString());
            int heightInches = Integer.parseInt(heightInchesInput.getText().toString());
            int heightTotalInches = heightInches + (12 * heightFeet);
            int heightCM = (int) Math.round(heightTotalInches * 2.54);
            int weight = Integer.parseInt(weightInput.getText().toString());

            // determine gender
            RadioButton maleButton = findViewById(R.id.radio_male);
            boolean isMale = maleButton.isChecked();

            // Mifflin-St Jeor equation
            double BMR;
            if (isMale) {
                BMR = (10 * weight) + (6.25 * heightCM) - (5 * age) + 5;
            }
            else {
                BMR = (10 * weight) + (6.25 * heightCM) - (5 * age) - 161;
            }


            int dailyIntake;
            switch (activityLevel) {
                case "Basal Metabolic Rate (BMR)":
                    dailyIntake = (int) BMR;
                    break;
                case "Little to none":
                    dailyIntake = (int) (BMR * 1.2);
                    break;
                case "Exercise 1–3 times/week":
                    dailyIntake = (int) (BMR * 1.375);
                    break;
                case "Exercise 4–5 times/week":
                    dailyIntake = (int) (BMR * 1.465);
                    break;
                case "Daily Exercise or Intense exercise 3–4 times/week":
                    dailyIntake = (int) (BMR * 1.55);
                    break;
                case "Intense exercise 6–7 times/week":
                    dailyIntake = (int) (BMR * 1.725);
                    break;
                case "Very intense exercise daily or Physical job":
                    dailyIntake = (int) (BMR * 1.9);
                    break;
                default:
                    Toast.makeText(this, "Select an activity level", Toast.LENGTH_SHORT).show();
                    return;
            }

            // Weight goal options
            int maintainCalories = dailyIntake;
            int mildLossCalories = dailyIntake - 300;     // mild deficit
            int moderateLossCalories = dailyIntake - 600; // moderate deficit

            // Prevent negative values (extremely rare but safe)
            if (mildLossCalories < 1200) mildLossCalories = 1200;
            if (moderateLossCalories < 1200) moderateLossCalories = 1200;

            Button buttonMaintain = findViewById(R.id.buttonMaintain);
            Button buttonMildLoss = findViewById(R.id.buttonMildLoss);
            Button buttonModerateLoss = findViewById(R.id.buttonModerateLoss);

            // Update button text with calorie values
            buttonMaintain.setText("Maintain Weight: " + maintainCalories + " cal/day");
            buttonMildLoss.setText("Mild Weight Loss: " + mildLossCalories + " cal/day");
            buttonModerateLoss.setText("Moderate Weight Loss: " + moderateLossCalories + " cal/day");

            // Make buttons visible
            buttonMaintain.setVisibility(View.VISIBLE);
            buttonMildLoss.setVisibility(View.VISIBLE);
            buttonModerateLoss.setVisibility(View.VISIBLE);

            buttonMaintain.setOnClickListener(v1 -> {
                db.saveCalorieGoal(username, maintainCalories);
                String username = getIntent().getStringExtra("username");
                Toast.makeText(this, "Maintain goal saved!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(CalorieGoalCalculatorActivity.this, DashboardActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
                finish();
            });

            int finalMildLossCalories = mildLossCalories;
            buttonMildLoss.setOnClickListener(v2 -> {
                db.saveCalorieGoal(username, finalMildLossCalories);
                String username = getIntent().getStringExtra("username");
                Toast.makeText(this, "Mild loss goal saved!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(CalorieGoalCalculatorActivity.this, DashboardActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
                finish();
            });

            int finalModerateLossCalories = moderateLossCalories;
            buttonModerateLoss.setOnClickListener(v3 -> {
                db.saveCalorieGoal(username, finalModerateLossCalories);
                String username = getIntent().getStringExtra("username");
                Toast.makeText(this, "Moderate loss goal saved!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(CalorieGoalCalculatorActivity.this, DashboardActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
                finish();
            });
        });
    }

    // handles spinner selection events
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        activityLevel = parent.getItemAtPosition(position).toString();
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        activityLevel = "";
    }

}
