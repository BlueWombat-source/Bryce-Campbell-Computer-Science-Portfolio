package com.example.project02;

import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class SelectWorkoutForDayActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private String username;
    private int dayNumber;
    private LinearLayout workoutListLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_workout_for_day);

        db = new DatabaseHelper(this);

        username = getIntent().getStringExtra("username");
        dayNumber = getIntent().getIntExtra("dayNumber", -1);

        workoutListLayout = findViewById(R.id.workoutListLayout);

        loadWorkouts();
    }

    private void loadWorkouts() {
        List<Workout> workouts = db.getWorkoutsForUser(username);

        for (Workout w : workouts) {
            Button workoutButton = new Button(this);
            workoutButton.setText(w.getCategory() + "\n" + w.getExercises().replace(",", ", "));
            workoutButton.setPadding(20, 20, 20, 20);

            workoutButton.setOnClickListener(v -> {
                db.assignWorkoutToDay(username, dayNumber, w.getId());
                finish();
            });

            workoutListLayout.addView(workoutButton);
        }
    }
}

