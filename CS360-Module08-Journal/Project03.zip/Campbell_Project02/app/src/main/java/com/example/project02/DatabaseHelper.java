package com.example.project02;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    // database Info
    private static final String DB_NAME = "WeightLog.db";
    private static final int DB_VERSION = 1;

    // weight log table info
    private static final String TABLE_WEIGHTLOGS = "weightlogs";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT ="weight";

    // users table info
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // goal weight table
    private static final String TABLE_GOAL = "goal";
    private static final String COLUMN_GOAL_ID = "goal_id";
    private static final String COLUMN_GOAL_WEIGHT = "goal_weight";
    private static final String COLUMN_GOAL_USER = "goal_user";

    // constructor
    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        // create users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT UNIQUE, "
                + COLUMN_PASSWORD + " TEXT)";

        // create weight log table
        String CREATE_WEIGHTLOGS_TABLE = "CREATE TABLE " + TABLE_WEIGHTLOGS + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_DATE + " TEXT NOT NULL,"
                + COLUMN_WEIGHT + " TEXT NOT NULL)";

        // create goal weight table
        String CREATE_GOAL_TABLE = "CREATE TABLE " + TABLE_GOAL + " ("
                + COLUMN_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_GOAL_USER + " TEXT, "
                + COLUMN_GOAL_WEIGHT + " TEXT)";

        db.execSQL(CREATE_USERS_TABLE);
        db.execSQL(CREATE_WEIGHTLOGS_TABLE);
        db.execSQL(CREATE_GOAL_TABLE);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop old table if exists
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTLOGS);
        onCreate(db);
    }

    /*** USER TABLE METHODS ***/

    // create new user
    public boolean createUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // check if credentials are valid
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " +
                        COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /*** WEIGHT LOG TABLE METHODS ***/

    // insert data
    public boolean insertLog(String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        long result = db.insert(TABLE_WEIGHTLOGS, null, values);

        return result != -1; // returns true if insert succeeds
    }

    // get all weight logs
    public Cursor getAllLogs() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHTLOGS + " ORDER BY " + COLUMN_ID + " DESC", null);
    }

    // get most recent weight log
    public String getMostRecentWeight() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT weight FROM weightlogs ORDER BY id DESC LIMIT 1",
                null
        );

        if (cursor.moveToFirst()) {
            String weight = cursor.getString(0);
            cursor.close();
            return weight;
        }

        cursor.close();
        return null;
    }

    // get initial weight log
    public String getInitialWeight() {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT weight FROM weightlogs ORDER BY id ASC LIMIT 1",
                null
        );

        if (cursor.moveToFirst()) {
            String weight = cursor.getString(0);
            cursor.close();
            return weight;
        }

        cursor.close();
        return null; // no logs yet
    }

    // delete log by id
    public boolean deleteLog(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_WEIGHTLOGS, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    // update weight log by id
    public boolean updateLog(int id, String newDate, String newWeight) {
        SQLiteDatabase db =this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_DATE, newDate);
        values.put(COLUMN_WEIGHT, newWeight);

        int rows = db.update(TABLE_WEIGHTLOGS,  values, COLUMN_ID+ "?=", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    /*** GOAL WEIGHT METHODS ***/

    // set goal weight
    public boolean setGoalWeight(String username, String goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_USER, username);
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        long result = db.insert(TABLE_GOAL, null, values);
        return result != -1;
    }

    // get goal weight
    public String getGoalWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT " + COLUMN_GOAL_WEIGHT + " FROM " + TABLE_GOAL +
                        " WHERE " + COLUMN_GOAL_USER + "=? LIMIT 1",
                new String[]{username}
        );

        if (cursor.moveToFirst()) {
            String goal = cursor.getString(0);
            cursor.close();
            return goal;
        }

        cursor.close();
        return null; // no goal set
    }
}
